package util;

public enum Permission {

	Admin,
	User,
	None
	
}
